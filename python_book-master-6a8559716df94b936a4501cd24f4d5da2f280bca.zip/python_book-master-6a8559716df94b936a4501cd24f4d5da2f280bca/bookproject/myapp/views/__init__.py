from myapp.views.admin import *
from myapp.views.index import *
