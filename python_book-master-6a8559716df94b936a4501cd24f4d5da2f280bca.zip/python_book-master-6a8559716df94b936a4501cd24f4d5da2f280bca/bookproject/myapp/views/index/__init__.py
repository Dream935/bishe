from myapp.views.index.classification import *
from myapp.views.index.tag import *
from myapp.views.index.user import *
from myapp.views.index.book import *
from myapp.views.index.comment import *
from myapp.views.index.borrow import *
from myapp.views.index.notice import *
from myapp.views.index.address import *
