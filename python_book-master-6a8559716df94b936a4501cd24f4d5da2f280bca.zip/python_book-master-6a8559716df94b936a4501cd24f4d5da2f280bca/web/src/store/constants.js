export const TOKEN = 'Token'
export const USERNAME = 'UserName'
export const USERID = 'UserId'

export const ADMIN_TOKEN = 'Admin-Token'
export const ADMIN_USERNAME = 'Admin-UserName'

export const BASE_URL = 'http://127.0.0.1:8000'
// export const BASE_URL = 'https://book.gitapp.cn/api/'
